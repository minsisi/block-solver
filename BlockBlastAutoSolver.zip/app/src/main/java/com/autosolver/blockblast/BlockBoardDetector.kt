package com.autosolver.blockblast

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class TrayPiece(
    val index: Int,
    val shape: Array<IntArray>,
    val center: PointF,
    val color: Int
)

data class BlockBoardState(
    val grid: Array<IntArray>,
    val cellRects: Array<Array<RectF>>,
    val cellWidth: Float,
    val cellHeight: Float,
    val pieces: List<TrayPiece>
)

data class BlockDetectionResult(
    val state: BlockBoardState?,
    val errorReason: String? = null
)

object BlockBoardDetector {

    fun detectWithReason(bitmap: Bitmap): BlockDetectionResult {
        val w = bitmap.width
        val h = bitmap.height
        val minDim = min(w, h)

        val searchTop = (h * 0.14f).toInt()
        val searchBottom = (h * 0.78f).toInt()
        val minBoardSize = (minDim * 0.42f).toInt()
        val maxXGap = max(8, (minDim * 0.012f).toInt())
        val maxYGap = max(12, (minDim * 0.018f).toInt())

        // 1. 8x8 보드 영역 검출 (어두운 초콜릿 격자 + 채도가 높은 보석 블록)
        val rowSpans = HashMap<Int, Pair<Int, Int>>()
        for (y in searchTop until searchBottom) {
            var bestL = -1
            var bestR = -1
            var curL = -1
            var gap = 0
            for (x in 0 until w) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val isBoardPx = ((r < 66) && (g < 46) && (b < 42) && ((r - b) >= 14)) ||
                    ((maxC > 125) && ((maxC - minC) > 55))
                if (isBoardPx) {
                    if (curL == -1) curL = x
                    gap = 0
                    if (x - curL > bestR - bestL) {
                        bestL = curL
                        bestR = x
                    }
                } else if (curL != -1) {
                    gap++
                    if (gap > maxXGap) {
                        curL = -1
                        gap = 0
                    }
                }
            }
            if (bestL != -1 && (bestR - bestL) >= minBoardSize) {
                rowSpans[y] = bestL to bestR
            }
        }

        val blocks = mutableListOf<List<Int>>()
        var curYs = mutableListOf<Int>()
        var yGap = 0
        for (y in searchTop until searchBottom) {
            if (rowSpans.containsKey(y)) {
                curYs.add(y)
                yGap = 0
            } else if (curYs.isNotEmpty()) {
                yGap++
                if (yGap > maxYGap) {
                    blocks.add(curYs)
                    curYs = mutableListOf()
                    yGap = 0
                }
            }
        }
        if (curYs.isNotEmpty()) blocks.add(curYs)

        var bTop = -1
        var bBottom = -1
        var bLeft = -1
        var bRight = -1
        var bestArea = 0L

        for (ys in blocks) {
            val bh = ys.last() - ys.first()
            if (bh < minBoardSize) continue
            val margin = max(1, ys.size / 10)
            val mid = if (ys.size > margin * 2) ys.subList(margin, ys.size - margin) else ys
            val bl = mid.map { rowSpans[it]!!.first }.sorted()[mid.size / 2]
            val br = mid.map { rowSpans[it]!!.second }.sorted()[mid.size / 2]
            val bw = br - bl
            if (bw >= minBoardSize && abs(bw - bh) <= minDim * 0.14f) {
                val area = bw.toLong() * bh.toLong()
                if (area > bestArea) {
                    bestArea = area
                    bTop = ys.first()
                    bBottom = ys.last()
                    bLeft = bl
                    bRight = br
                }
            }
        }

        if (bTop == -1) {
            return BlockDetectionResult(null, "8x8 보드를 찾지 못했습니다 (화면 ${w}x${h})")
        }

        val bw = (bRight - bLeft).toFloat()
        val bh = (bBottom - bTop).toFloat()
        val gridLeft = bLeft + bw * 0.022f
        val gridRight = bRight - bw * 0.012f
        val gridTop = bTop + bh * 0.012f
        val gridBottom = bBottom - bh * 0.022f

        val cellW = (gridRight - gridLeft) / 8f
        val cellH = (gridBottom - gridTop) / 8f

        val grid = Array(8) { IntArray(8) }
        val cellRects = Array(8) { r ->
            Array(8) { c ->
                val l = gridLeft + c * cellW
                val t = gridTop + r * cellH
                RectF(l, t, l + cellW, t + cellH)
            }
        }

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val rect = cellRects[r][c]
                val cx = rect.centerX().toInt()
                val cy = rect.centerY().toInt()
                var rSum = 0
                var gSum = 0
                var bSum = 0
                var cnt = 0
                for (dy in -2..2) {
                    for (dx in -2..2) {
                        val p = bitmap.getPixel((cx + dx).coerceIn(0, w - 1), (cy + dy).coerceIn(0, h - 1))
                        rSum += Color.red(p)
                        gSum += Color.green(p)
                        bSum += Color.blue(p)
                        cnt++
                    }
                }
                val mr = rSum / cnt
                val mg = gSum / cnt
                val mb = bSum / cnt
                val maxC = max(mr, max(mg, mb))
                val sat = maxC - min(mr, min(mg, mb))
                grid[r][c] = if (maxC > 85 || sat > 40) 1 else 0
            }
        }

        // 2. 하단 트레이의 대기 블록(최대 3개) 추출
        val trayTop = (gridBottom + cellH * 0.25f).toInt().coerceIn(0, h - 1)
        val trayBottom = (gridBottom + cellH * 3.6f).toInt().coerceIn(0, h)
        if (trayBottom <= trayTop + 10) {
            return BlockDetectionResult(null, "하단 블록 영역을 찾지 못했습니다.")
        }

        val colHasPiece = BooleanArray(w)
        for (x in 0 until w) {
            for (y in trayTop until trayBottom) {
                val p = bitmap.getPixel(x, y)
                val maxC = max(Color.red(p), max(Color.green(p), Color.blue(p)))
                val sat = maxC - min(Color.red(p), min(Color.green(p), Color.blue(p)))
                if (maxC > 125 && sat > 55) {
                    colHasPiece[x] = true
                    break
                }
            }
        }

        val xRuns = mutableListOf<Pair<Int, Int>>()
        var inRun = false
        var startX = 0
        val minPieceWidth = (cellW * 0.30f).toInt()
        for (x in 0 until w) {
            if (colHasPiece[x]) {
                if (!inRun) {
                    inRun = true
                    startX = x
                }
            } else if (inRun) {
                inRun = false
                if (x - startX >= minPieceWidth) {
                    xRuns.add(startX to (x - 1))
                }
            }
        }

        val miniCell = cellW * 0.452f
        val pieces = mutableListOf<TrayPiece>()
        val fallbackColors = intArrayOf(
            Color.rgb(250, 204, 21),
            Color.rgb(244, 63, 94),
            Color.rgb(217, 70, 239)
        )

        xRuns.forEachIndexed { idx, (x0, x1) ->
            var y0 = trayBottom
            var y1 = trayTop
            val rs = mutableListOf<Int>()
            val gs = mutableListOf<Int>()
            val bs = mutableListOf<Int>()

            for (y in trayTop until trayBottom) {
                for (x in x0..x1) {
                    val p = bitmap.getPixel(x, y)
                    val r = Color.red(p)
                    val g = Color.green(p)
                    val b = Color.blue(p)
                    val maxC = max(r, max(g, b))
                    val sat = maxC - min(r, min(g, b))
                    if (maxC > 125 && sat > 55) {
                        if (y < y0) y0 = y
                        if (y > y1) y1 = y
                        if (maxC > 135 && sat > 65) {
                            rs.add(r)
                            gs.add(g)
                            bs.add(b)
                        }
                    }
                }
            }

            if (y1 >= y0) {
                val pw = (x1 - x0 + 1).toFloat()
                val ph = (y1 - y0 + 1).toFloat()
                val colsN = (pw / miniCell).roundToInt().coerceIn(1, 5)
                val rowsN = (ph / miniCell).roundToInt().coerceIn(1, 5)
                val stepX = pw / colsN
                val stepY = ph / rowsN

                val shape = Array(rowsN) { IntArray(colsN) }
                var filled = 0
                for (rr in 0 until rowsN) {
                    val sy = (y0 + (rr + 0.5f) * stepY).toInt().coerceIn(0, h - 1)
                    for (cc in 0 until colsN) {
                        val sx = (x0 + (cc + 0.5f) * stepX).toInt().coerceIn(0, w - 1)
                        val p = bitmap.getPixel(sx, sy)
                        val maxC = max(Color.red(p), max(Color.green(p), Color.blue(p)))
                        val sat = maxC - min(Color.red(p), min(Color.green(p), Color.blue(p)))
                        if (maxC > 120 && sat > 50) {
                            shape[rr][cc] = 1
                            filled++
                        }
                    }
                }

                if (filled > 0) {
                    val pieceColor = if (rs.isNotEmpty()) {
                        rs.sort()
                        gs.sort()
                        bs.sort()
                        Color.rgb(rs[rs.size / 2], gs[gs.size / 2], bs[bs.size / 2])
                    } else {
                        fallbackColors[idx % fallbackColors.size]
                    }

                    pieces.add(
                        TrayPiece(
                            index = idx,
                            shape = shape,
                            center = PointF((x0 + x1) / 2f, (y0 + y1) / 2f),
                            color = pieceColor
                        )
                    )
                }
            }
        }

        if (pieces.isEmpty()) {
            return BlockDetectionResult(null, "하단 블록 3개를 인식하지 못했습니다.")
        }

        return BlockDetectionResult(BlockBoardState(grid, cellRects, cellW, cellH, pieces))
    }
}
