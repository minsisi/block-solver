package com.autosolver.blockblast

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 3001
        private const val REQ_NOTIF = 3002
    }

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val gap = (12 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "블록 퍼즐 자동 배치"
            textSize = 22f
            setTextColor(Color.parseColor("#92400E"))
        }

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, gap, 0, gap)
            setTextColor(Color.parseColor("#334155"))
        }

        val overlayBtn = Button(this).apply {
            text = "1. 다른 앱 위에 표시 권한 열기 (필수)"
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        val accBtn = Button(this).apply {
            text = "2. 접근성 권한 열기 (자동배치용)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val startBtn = Button(this).apply {
            text = "3. 플로팅 바 시작하기"
            setOnClickListener { startCaptureFlow() }
        }

        val stopBtn = Button(this).apply {
            text = "플로팅 바 종료"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingBlockSolverService::class.java))
                Toast.makeText(this@MainActivity, "종료되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }

        val guide = TextView(this).apply {
            textSize = 13f
            setPadding(0, gap * 2, 0, 0)
            setTextColor(Color.parseColor("#475569"))
            text = listOf(
                "사용 방법:",
                "• [위치표시]: 1번 권한만 있어도 바로 사용 가능하며, 8x8 보드 위에 1→2→3번 블록이 들어갈 자리를 색상 박스로 표시해 줍니다.",
                "• [자동배치]: 2번 접근성 권한까지 켜면 하단 블록 3개를 순서대로 자동 드래그해 놓습니다.",
                "• [보정:1.5]: 자동배치 시 블록이 목표보다 위나 아래에 놓이면 눌러서 높이(1.5 / 2.0 / 0.0 / 1.0칸)를 맞추세요.",
                "• [지움]: 보드 위의 위치 표시 박스를 지웁니다."
            ).joinToString("\n")
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(overlayBtn)
        root.addView(accBtn)
        root.addView(startBtn)
        root.addView(stopBtn)
        root.addView(guide)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accOk = AutoDragService.instance != null
        statusText.text =
            "다른 앱 위에 표시 (위치표시/공통): ${if (overlayOk) "허용됨 ✅" else "필요 ❌"}\n" +
            "접근성 서비스 (자동배치용): ${if (accOk) "켜짐 ✅" else "꺼짐 (위치표시는 가능)"}"
    }

    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "먼저 1번 오버레이 권한을 허용하세요.", Toast.LENGTH_SHORT).show()
            return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, FloatingBlockSolverService::class.java).apply {
                    putExtra(FloatingBlockSolverService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(FloatingBlockSolverService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(serviceIntent)
                Toast.makeText(this, "플로팅 바가 시작되었습니다!", Toast.LENGTH_SHORT).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "화면 공유가 취소되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
