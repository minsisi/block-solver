package com.autosolver.blockblast

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

class GhostOverlayView(context: Context) : View(context) {

    private var boardState: BlockBoardState? = null
    private var steps: List<PlacementStep> = emptyList()

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(225, 15, 23, 42)
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun showSolution(state: BlockBoardState, plan: List<PlacementStep>) {
        boardState = state
        steps = plan
        visibility = VISIBLE
        invalidate()
    }

    fun clearSolution() {
        steps = emptyList()
        visibility = GONE
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = boardState ?: return
        if (steps.isEmpty()) return

        val inset = state.cellWidth * 0.08f
        val corner = state.cellWidth * 0.16f

        steps.forEachIndexed { orderIdx, step ->
            val baseColor = step.piece.color
            val r = Color.red(baseColor)
            val g = Color.green(baseColor)
            val b = Color.blue(baseColor)

            // 순서(1, 2, 3)가 겹칠 때도 구분되도록 투명도 및 테두리 조절
            fillPaint.color = Color.argb(105, r, g, b)
            strokePaint.color = Color.argb(245, r, g, b)

            val shape = step.piece.shape
            var sumX = 0f
            var sumY = 0f
            var count = 0

            for (sr in shape.indices) {
                for (sc in shape[0].indices) {
                    if (shape[sr][sc] == 1) {
                        val br = step.targetRow + sr
                        val bc = step.targetCol + sc
                        if (br in 0..7 && bc in 0..7) {
                            val cellRect = state.cellRects[br][bc]
                            val drawRect = RectF(
                                cellRect.left + inset,
                                cellRect.top + inset,
                                cellRect.right - inset,
                                cellRect.bottom - inset
                            )
                            canvas.drawRoundRect(drawRect, corner, corner, fillPaint)
                            canvas.drawRoundRect(drawRect, corner, corner, strokePaint)
                            sumX += cellRect.centerX()
                            sumY += cellRect.centerY()
                            count++
                        }
                    }
                }
            }

            if (count > 0) {
                val cx = sumX / count
                val cy = sumY / count
                val badgeRadius = state.cellWidth * 0.30f
                canvas.drawCircle(cx, cy, badgeRadius, badgeBgPaint)
                strokePaint.color = baseColor
                canvas.drawCircle(cx, cy, badgeRadius, strokePaint)

                textPaint.textSize = state.cellWidth * 0.38f
                val fontMetrics = textPaint.fontMetrics
                val textY = cy - (fontMetrics.ascent + fontMetrics.descent) / 2f
                canvas.drawText("${orderIdx + 1}", cx, textY, textPaint)
            }
        }
    }
}
