package com.autosolver.blockblast

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoDragService : AccessibilityService() {

    companion object {
        var instance: AutoDragService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun dragSequence(
        drags: List<Pair<PointF, PointF>>,
        stepIntervalMs: Long = 860L,
        dragDurationMs: Long = 340L
    ) {
        drags.forEachIndexed { idx, (from, to) ->
            handler.postDelayed({
                performDrag(from, to, dragDurationMs)
            }, idx * stepIntervalMs)
        }
    }

    private fun performDrag(from: PointF, to: PointF, durationMs: Long) {
        val path = Path().apply {
            moveTo(from.x, from.y)
            lineTo(to.x, to.y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
