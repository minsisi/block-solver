package com.autosolver.blockblast

data class PlacementStep(
    val piece: TrayPiece,
    val targetRow: Int,
    val targetCol: Int,
    val clearedLines: Int
)

object BlockSolver {

    fun findBestSequence(board: Array<IntArray>, pieces: List<TrayPiece>): List<PlacementStep>? {
        val perms = permutations(pieces)
        var bestScore = Int.MIN_VALUE
        var bestPlan: List<PlacementStep>? = null

        fun dfs(
            curBoard: Array<IntArray>,
            ordered: List<TrayPiece>,
            depth: Int,
            accLines: Int,
            comboCount: Int,
            accSteps: MutableList<PlacementStep>
        ) {
            if (depth == ordered.size) {
                val score = accLines * 120 +
                    (if (comboCount >= 2) comboCount * 50 else 0) +
                    evaluateBoard(curBoard)
                if (score > bestScore) {
                    bestScore = score
                    bestPlan = accSteps.toList()
                }
                return
            }

            val piece = ordered[depth]
            val sh = piece.shape.size
            val sw = piece.shape[0].size

            for (r in 0..(8 - sh)) {
                for (c in 0..(8 - sw)) {
                    if (!canPlace(curBoard, piece.shape, r, c)) continue
                    val (nextBoard, lines) = placeAndClear(curBoard, piece.shape, r, c)
                    accSteps.add(PlacementStep(piece, r, c, lines))
                    dfs(
                        nextBoard,
                        ordered,
                        depth + 1,
                        accLines + lines,
                        comboCount + (if (lines > 0) 1 else 0),
                        accSteps
                    )
                    accSteps.removeAt(accSteps.lastIndex)
                }
            }
        }

        for (perm in perms) {
            dfs(board, perm, 0, 0, 0, mutableListOf())
        }
        return bestPlan
    }

    private fun canPlace(b: Array<IntArray>, shape: Array<IntArray>, r0: Int, c0: Int): Boolean {
        for (r in shape.indices) {
            for (c in shape[0].indices) {
                if (shape[r][c] == 1 && b[r0 + r][c0 + c] == 1) return false
            }
        }
        return true
    }

    private fun placeAndClear(
        b: Array<IntArray>,
        shape: Array<IntArray>,
        r0: Int,
        c0: Int
    ): Pair<Array<IntArray>, Int> {
        val nb = Array(8) { r -> b[r].clone() }
        for (r in shape.indices) {
            for (c in shape[0].indices) {
                if (shape[r][c] == 1) nb[r0 + r][c0 + c] = 1
            }
        }
        val fullRows = (0 until 8).filter { r -> (0 until 8).all { c -> nb[r][c] == 1 } }
        val fullCols = (0 until 8).filter { c -> (0 until 8).all { r -> nb[r][c] == 1 } }
        for (r in fullRows) for (c in 0 until 8) nb[r][c] = 0
        for (c in fullCols) for (r in 0 until 8) nb[r][c] = 0
        return nb to (fullRows.size + fullCols.size)
    }

    private fun evaluateBoard(b: Array<IntArray>): Int {
        var occ = 0
        var holes = 0
        var transitions = 0

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                occ += b[r][c]
                if (b[r][c] == 0) {
                    var blocked = 0
                    if (r == 0 || b[r - 1][c] == 1) blocked++
                    if (r == 7 || b[r + 1][c] == 1) blocked++
                    if (c == 0 || b[r][c - 1] == 1) blocked++
                    if (c == 7 || b[r][c + 1] == 1) blocked++
                    if (blocked == 4) holes += 3 else if (blocked == 3) holes += 1
                }
                if (c < 7 && b[r][c] != b[r][c + 1]) transitions++
                if (r < 7 && b[r][c] != b[r + 1][c]) transitions++
            }
        }

        var open3x3 = 0
        for (r in 0..5) {
            for (c in 0..5) {
                var empty = true
                for (dr in 0..2) {
                    for (dc in 0..2) {
                        if (b[r + dr][c + dc] == 1) empty = false
                    }
                }
                if (empty) open3x3++
            }
        }
        return -occ * 12 - holes * 15 - transitions * 2 + open3x3 * 8
    }

    private fun <T> permutations(list: List<T>): List<List<T>> {
        if (list.size <= 1) return listOf(list)
        val res = mutableListOf<List<T>>()
        for (i in list.indices) {
            val sub = list.toMutableList().apply { removeAt(i) }
            for (p in permutations(sub)) {
                res.add(listOf(list[i]) + p)
            }
        }
        return res
    }
}
