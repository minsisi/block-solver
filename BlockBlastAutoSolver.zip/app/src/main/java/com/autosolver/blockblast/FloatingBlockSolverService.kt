package com.autosolver.blockblast

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingBlockSolverService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "block_blast_solver_channel"
        private const val NOTIF_ID = 3001
    }

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var floatingView: View? = null
    private var ghostOverlayView: GhostOverlayView? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 420
    private var isBusy = false

    // 드래그 시 손가락 위로 블록이 떠오르는 높이 보정값(칸 단위)
    private val liftPresets = floatArrayOf(1.5f, 2.0f, 0.0f, 1.0f)
    private var liftIndex = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        initScreenMetrics()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            Toast.makeText(this, "화면 캡처 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
            stopSelf()
            return START_NOT_STICKY
        }

        setupMediaProjection(resultCode, resultData)
        setupOverlays()

        return START_NOT_STICKY
    }

    private fun initScreenMetrics() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            screenDensity = resources.displayMetrics.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
        }
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        releaseProjection()
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mgr.getMediaProjection(resultCode, data) ?: return
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { stopSelf() }
            }
        }, handler)

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        val display = projection.createVirtualDisplay(
            "BlockBlastCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        mediaProjection = projection
        imageReader = reader
        virtualDisplay = display
    }

    private fun setupOverlays() {
        if (ghostOverlayView == null) {
            val ghost = GhostOverlayView(this).apply {
                visibility = View.GONE
            }
            val ghostParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 0
            }
            ghostOverlayView = ghost
            windowManager.addView(ghost, ghostParams)
        }

        if (floatingView != null) return

        val density = resources.displayMetrics.density
        val padH = (10 * density).toInt()
        val padV = (7 * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(padH, padV, padH, padV)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61E1B18"))
                cornerRadius = 24 * density
                setStroke((1 * density).toInt(), Color.parseColor("#F59E0B"))
            }
        }

        val hintBtn = TextView(this).apply {
            text = "위치표시"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(padH, padV / 2, padH, padV / 2)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D97706"))
                cornerRadius = 14 * density
            }
            setOnClickListener { runSolve(autoDrag = false) }
        }

        val autoBtn = TextView(this).apply {
            text = "자동배치"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(padH, padV / 2, padH, padV / 2)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#059669"))
                cornerRadius = 14 * density
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = (6 * density).toInt()
            }
            layoutParams = lp
            setOnClickListener { runSolve(autoDrag = true) }
        }

        val liftBtn = TextView(this).apply {
            text = "보정:${liftPresets[liftIndex]}"
            setTextColor(Color.parseColor("#FDE68A"))
            textSize = 12f
            setPadding(padH, padV / 2, padH / 2, padV / 2)
            setOnClickListener {
                liftIndex = (liftIndex + 1) % liftPresets.size
                text = "보정:${liftPresets[liftIndex]}"
                Toast.makeText(
                    this@FloatingBlockSolverService,
                    "드래그 높이 보정: ${liftPresets[liftIndex]}칸",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val clearBtn = TextView(this).apply {
            text = "지움"
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 12f
            setPadding(padH / 2, padV / 2, padH / 2, padV / 2)
            setOnClickListener { ghostOverlayView?.clearSolution() }
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FCA5A5"))
            textSize = 14f
            setPadding(padH / 2, padV / 2, padH / 2, padV / 2)
            setOnClickListener { stopSelf() }
        }

        container.addView(hintBtn)
        container.addView(autoBtn)
        container.addView(liftBtn)
        container.addView(clearBtn)
        container.addView(closeBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (18 * density).toInt()
            y = (90 * density).toInt()
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }

        floatingView = container
        windowManager.addView(container, params)
    }

    private fun runSolve(autoDrag: Boolean) {
        if (isBusy) return
        val dragService = AutoDragService.instance
        if (autoDrag && dragService == null) {
            Toast.makeText(this, "자동배치는 접근성 권한이 필요합니다. 먼저 [위치표시]를 쓰거나 접근성을 켜주세요.", Toast.LENGTH_LONG).show()
            return
        }

        isBusy = true
        val wasGhostVisible = ghostOverlayView?.visibility == View.VISIBLE
        ghostOverlayView?.visibility = View.GONE
        floatingView?.visibility = View.INVISIBLE

        handler.postDelayed({
            val bitmap = grabLatestBitmap()
            floatingView?.visibility = View.VISIBLE

            if (bitmap == null) {
                if (wasGhostVisible) ghostOverlayView?.visibility = View.VISIBLE
                Toast.makeText(this, "화면 캡처 실패. 다시 눌러주세요.", Toast.LENGTH_SHORT).show()
                isBusy = false
                return@postDelayed
            }

            Thread {
                val detection = BlockBoardDetector.detectWithReason(bitmap)
                bitmap.recycle()

                val state = detection.state
                if (state == null) {
                    handler.post {
                        Toast.makeText(
                            this,
                            "인식 실패: ${detection.errorReason ?: "알 수 없음"}",
                            Toast.LENGTH_LONG
                        ).show()
                        isBusy = false
                    }
                    return@Thread
                }

                val plan = BlockSolver.findBestSequence(state.grid, state.pieces)
                if (plan == null || plan.isEmpty()) {
                    handler.post {
                        Toast.makeText(this, "배치 가능한 최적 경로를 찾지 못했습니다.", Toast.LENGTH_SHORT).show()
                        isBusy = false
                    }
                    return@Thread
                }

                val totalCleared = plan.sumOf { it.clearedLines }
                val liftCells = liftPresets[liftIndex]

                handler.post {
                    if (!autoDrag) {
                        ghostOverlayView?.showSolution(state, plan)
                        Toast.makeText(
                            this,
                            "1→2→3 최적 위치 표시 (예상 ${totalCleared}줄 제거)",
                            Toast.LENGTH_SHORT
                        ).show()
                        isBusy = false
                    } else {
                        ghostOverlayView?.clearSolution()
                        val drags = plan.map { step ->
                            val sh = step.piece.shape.size
                            val sw = step.piece.shape[0].size
                            val topLeftRect = state.cellRects[step.targetRow][step.targetCol]
                            val targetCenterX = topLeftRect.left + (sw * state.cellWidth) / 2f
                            val targetCenterY = topLeftRect.top + (sh * state.cellHeight) / 2f + liftCells * state.cellHeight
                            step.piece.center to PointF(targetCenterX, targetCenterY)
                        }
                        Toast.makeText(
                            this,
                            "자동 배치 실행 중... (예상 ${totalCleared}줄 제거)",
                            Toast.LENGTH_SHORT
                        ).show()
                        dragService?.dragSequence(drags, stepIntervalMs = 860L, dragDurationMs = 340L)
                        handler.postDelayed({ isBusy = false }, drags.size * 880L + 400L)
                    }
                }
            }.start()
        }, 150L)
    }

    private fun grabLatestBitmap(): Bitmap? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val fullBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            fullBitmap.copyPixelsFromBuffer(buffer)
            if (rowPadding == 0) {
                fullBitmap
            } else {
                val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, screenWidth, screenHeight)
                fullBitmap.recycle()
                cropped
            }
        } catch (_: Exception) {
            null
        } finally {
            image.close()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "블록 퍼즐 자동 배치",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("블록 퍼즐 자동 배치 실행 중")
            .setContentText("게임 화면에서 [위치표시] 또는 [자동배치]를 눌러주세요.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun releaseProjection() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        ghostOverlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        ghostOverlayView = null
        releaseProjection()
    }
}
